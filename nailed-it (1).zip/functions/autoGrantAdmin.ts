import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

const AUTO_ADMIN_EMAILS = ['trimena@hotmail.ca'];

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        // Check if user email is in auto-admin list and not already admin
        if (AUTO_ADMIN_EMAILS.includes(user.email) && user.role !== 'admin') {
            // Update user role to admin
            await base44.asServiceRole.entities.User.update(user.id, { role: 'admin' });
            return Response.json({ 
                success: true, 
                message: 'Admin access granted',
                isAdmin: true 
            });
        }

        return Response.json({ 
            success: true, 
            isAdmin: user.role === 'admin' 
        });
    } catch (error) {
        return Response.json({ error: error.message }, { status: 500 });
    }
});