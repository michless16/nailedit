import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { appointment_id, notification_type } = await req.json();

    // Get appointment details
    const appointments = await base44.asServiceRole.entities.Appointment.filter({ id: appointment_id });
    const appointment = appointments[0];

    if (!appointment) {
      return Response.json({ error: 'Appointment not found' }, { status: 404 });
    }

    // Check if client wants this notification
    const prefs = appointment.notification_preferences || {};
    const notificationsSent = appointment.notifications_sent || {};

    // Determine if we should send based on type
    let shouldSend = false;
    let updateField = '';

    if (notification_type === 'confirmation' && prefs.send_confirmation !== false && !notificationsSent.confirmation_sent) {
      shouldSend = true;
      updateField = 'confirmation_sent';
    } else if (notification_type === 'reminder' && prefs.send_reminder !== false && !notificationsSent.reminder_sent) {
      shouldSend = true;
      updateField = 'reminder_sent';
    } else if (notification_type === 'thank_you' && prefs.send_thank_you !== false && !notificationsSent.thank_you_sent) {
      shouldSend = true;
      updateField = 'thank_you_sent';
    }

    if (!shouldSend) {
      return Response.json({ message: 'Notification not sent (already sent or disabled by client)' });
    }

    if (!appointment.client_email) {
      return Response.json({ error: 'No email address for client' }, { status: 400 });
    }

    // Get shop settings for name
    const settings = await base44.asServiceRole.entities.ShopSettings.list();
    const shopName = settings[0]?.shop_name || 'Salon de Beauté';

    // Prepare email content based on type
    let subject = '';
    let body = '';

    if (notification_type === 'confirmation') {
      subject = `✨ Confirmation de votre rendez-vous - ${shopName}`;
      body = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #000; color: #fff;">
          <div style="text-align: center; padding: 30px 0; border-bottom: 2px solid #f43f5e;">
            <h1 style="color: #f43f5e; margin: 0;">✨ ${shopName}</h1>
          </div>
          
          <div style="padding: 30px 0;">
            <h2 style="color: #f43f5e;">Bonjour ${appointment.client_name},</h2>
            <p style="font-size: 16px; line-height: 1.6;">
              Votre rendez-vous a été confirmé avec succès! Nous avons hâte de vous accueillir.
            </p>
            
            <div style="background-color: #18181b; padding: 20px; border-radius: 10px; margin: 20px 0; border-left: 4px solid #f43f5e;">
              <h3 style="color: #f43f5e; margin-top: 0;">Détails du rendez-vous</h3>
              <p style="margin: 10px 0;"><strong>Service:</strong> ${appointment.service_name}</p>
              <p style="margin: 10px 0;"><strong>Date:</strong> ${new Date(appointment.date).toLocaleDateString('fr-FR', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
              <p style="margin: 10px 0;"><strong>Heure:</strong> ${appointment.time}</p>
              <p style="margin: 10px 0;"><strong>Technicienne:</strong> ${appointment.technician_name}</p>
              <p style="margin: 10px 0;"><strong>Prix:</strong> ${appointment.service_price}$</p>
            </div>
            
            ${appointment.notes ? `<p style="font-size: 14px; color: #a1a1aa;"><strong>Note:</strong> ${appointment.notes}</p>` : ''}
            
            <p style="font-size: 14px; color: #a1a1aa; margin-top: 20px;">
              Si vous avez besoin de modifier ou annuler votre rendez-vous, contactez-nous au plus vite.
            </p>
          </div>
          
          <div style="text-align: center; padding: 20px 0; border-top: 1px solid #27272a; font-size: 12px; color: #71717a;">
            <p>À bientôt chez ${shopName}</p>
          </div>
        </div>
      `;
    } else if (notification_type === 'reminder') {
      subject = `⏰ Rappel: Votre rendez-vous demain - ${shopName}`;
      body = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #000; color: #fff;">
          <div style="text-align: center; padding: 30px 0; border-bottom: 2px solid #f43f5e;">
            <h1 style="color: #f43f5e; margin: 0;">⏰ ${shopName}</h1>
          </div>
          
          <div style="padding: 30px 0;">
            <h2 style="color: #f43f5e;">Bonjour ${appointment.client_name},</h2>
            <p style="font-size: 16px; line-height: 1.6;">
              Petit rappel amical: votre rendez-vous est prévu pour demain!
            </p>
            
            <div style="background-color: #18181b; padding: 20px; border-radius: 10px; margin: 20px 0; border-left: 4px solid #f43f5e;">
              <h3 style="color: #f43f5e; margin-top: 0;">Détails du rendez-vous</h3>
              <p style="margin: 10px 0;"><strong>Service:</strong> ${appointment.service_name}</p>
              <p style="margin: 10px 0;"><strong>Date:</strong> ${new Date(appointment.date).toLocaleDateString('fr-FR', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
              <p style="margin: 10px 0;"><strong>Heure:</strong> ${appointment.time}</p>
              <p style="margin: 10px 0;"><strong>Technicienne:</strong> ${appointment.technician_name}</p>
            </div>
            
            <p style="font-size: 14px; color: #a1a1aa; margin-top: 20px;">
              Nous avons hâte de vous voir! N'hésitez pas à nous contacter si vous avez des questions.
            </p>
          </div>
          
          <div style="text-align: center; padding: 20px 0; border-top: 1px solid #27272a; font-size: 12px; color: #71717a;">
            <p>À demain chez ${shopName}</p>
          </div>
        </div>
      `;
    } else if (notification_type === 'thank_you') {
      subject = `💖 Merci pour votre visite - ${shopName}`;
      body = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #000; color: #fff;">
          <div style="text-align: center; padding: 30px 0; border-bottom: 2px solid #f43f5e;">
            <h1 style="color: #f43f5e; margin: 0;">💖 ${shopName}</h1>
          </div>
          
          <div style="padding: 30px 0;">
            <h2 style="color: #f43f5e;">Merci ${appointment.client_name}!</h2>
            <p style="font-size: 16px; line-height: 1.6;">
              Nous espérons que vous avez apprécié votre expérience avec nous. Ce fut un plaisir de prendre soin de vous!
            </p>
            
            <div style="background-color: #18181b; padding: 20px; border-radius: 10px; margin: 20px 0; text-align: center;">
              <p style="font-size: 18px; color: #f43f5e; margin: 0;">
                ✨ Prenez soin de vos ongles ✨
              </p>
            </div>
            
            <p style="font-size: 16px; line-height: 1.6;">
              N'hésitez pas à nous laisser un avis ou à nous contacter si vous avez des questions sur l'entretien de vos ongles.
            </p>
            
            <p style="font-size: 16px; line-height: 1.6;">
              Nous serions ravis de vous revoir bientôt pour votre prochain soin!
            </p>
          </div>
          
          <div style="text-align: center; padding: 20px 0; border-top: 1px solid #27272a; font-size: 12px; color: #71717a;">
            <p>À bientôt chez ${shopName}</p>
          </div>
        </div>
      `;
    }

    // Send email
    await base44.asServiceRole.integrations.Core.SendEmail({
      to: appointment.client_email,
      subject: subject,
      body: body
    });

    // Update appointment to mark notification as sent
    const updatedNotificationsSent = { ...notificationsSent };
    updatedNotificationsSent[updateField] = true;

    await base44.asServiceRole.entities.Appointment.update(appointment_id, {
      notifications_sent: updatedNotificationsSent
    });

    return Response.json({ 
      success: true, 
      message: `${notification_type} notification sent successfully` 
    });

  } catch (error) {
    console.error('Error sending notification:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});