import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    // Get tomorrow's date
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const tomorrowStr = tomorrow.toISOString().split('T')[0];

    // Get all confirmed appointments for tomorrow
    const appointments = await base44.asServiceRole.entities.Appointment.filter({
      date: tomorrowStr,
      status: 'confirmed'
    });

    let sentCount = 0;
    const errors = [];

    // Send reminders for each appointment
    for (const appointment of appointments) {
      try {
        const notificationsSent = appointment.notifications_sent || {};
        const prefs = appointment.notification_preferences || {};

        // Skip if already sent or client doesn't want reminders
        if (notificationsSent.reminder_sent || prefs.send_reminder === false) {
          continue;
        }

        // Call the notification function
        await base44.asServiceRole.functions.invoke('sendBookingNotifications', {
          appointment_id: appointment.id,
          notification_type: 'reminder'
        });

        sentCount++;
      } catch (error) {
        errors.push({ appointment_id: appointment.id, error: error.message });
      }
    }

    return Response.json({
      success: true,
      message: `Sent ${sentCount} reminder notifications`,
      errors: errors.length > 0 ? errors : undefined
    });

  } catch (error) {
    console.error('Error in reminder automation:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});