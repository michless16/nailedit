import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    // Get yesterday's date
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split('T')[0];

    // Get all completed appointments from yesterday
    const appointments = await base44.asServiceRole.entities.Appointment.filter({
      date: yesterdayStr,
      status: 'completed'
    });

    let sentCount = 0;
    const errors = [];

    // Send thank you messages for each appointment
    for (const appointment of appointments) {
      try {
        const notificationsSent = appointment.notifications_sent || {};
        const prefs = appointment.notification_preferences || {};

        // Skip if already sent or client doesn't want thank you messages
        if (notificationsSent.thank_you_sent || prefs.send_thank_you === false) {
          continue;
        }

        // Call the notification function
        await base44.asServiceRole.functions.invoke('sendBookingNotifications', {
          appointment_id: appointment.id,
          notification_type: 'thank_you'
        });

        sentCount++;
      } catch (error) {
        errors.push({ appointment_id: appointment.id, error: error.message });
      }
    }

    return Response.json({
      success: true,
      message: `Sent ${sentCount} thank you notifications`,
      errors: errors.length > 0 ? errors : undefined
    });

  } catch (error) {
    console.error('Error in thank you automation:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});