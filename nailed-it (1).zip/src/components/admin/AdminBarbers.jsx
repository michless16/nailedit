import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Card } from "@/components/ui/card";
import { Plus, Pencil, Trash2, Loader2, User } from 'lucide-react';
import { toast } from "sonner";

export default function AdminBarbers() {
  const [isOpen, setIsOpen] = useState(false);
  const [editingBarber, setEditingBarber] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    title: '',
    bio: '',
    photo_url: '',
    is_active: true,
    order: 0
  });

  const queryClient = useQueryClient();

  const { data: barbers, isLoading } = useQuery({
    queryKey: ['barbers-admin'],
    queryFn: () => base44.entities.Barber.list('order')
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Barber.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['barbers-admin']);
      queryClient.invalidateQueries(['barbers']);
      toast.success('Barbier ajouté avec succès');
      resetForm();
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Barber.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['barbers-admin']);
      queryClient.invalidateQueries(['barbers']);
      toast.success('Barbier mis à jour');
      resetForm();
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Barber.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['barbers-admin']);
      queryClient.invalidateQueries(['barbers']);
      toast.success('Barbier supprimé');
    }
  });

  const resetForm = () => {
    setFormData({
      name: '',
      title: '',
      bio: '',
      photo_url: '',
      is_active: true,
      order: 0
    });
    setEditingBarber(null);
    setIsOpen(false);
  };

  const handleEdit = (barber) => {
    setEditingBarber(barber);
    setFormData({
      name: barber.name,
      title: barber.title || '',
      bio: barber.bio || '',
      photo_url: barber.photo_url || '',
      is_active: barber.is_active ?? true,
      order: barber.order || 0
    });
    setIsOpen(true);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingBarber) {
      updateMutation.mutate({ id: editingBarber.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleDelete = (id) => {
    if (window.confirm('Êtes-vous sûr de vouloir supprimer ce barbier ?')) {
      deleteMutation.mutate(id);
    }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-white">Barbiers</h2>
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button className="bg-amber-500 hover:bg-amber-600 text-black">
              <Plus className="w-4 h-4 mr-2" />
              Nouveau Barbier
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-zinc-900 border-zinc-800 text-white max-w-md">
            <DialogHeader>
              <DialogTitle>
                {editingBarber ? 'Modifier le barbier' : 'Nouveau barbier'}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label>Nom *</Label>
                <Input
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="bg-zinc-800 border-zinc-700"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label>Titre / Spécialité</Label>
                <Input
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="bg-zinc-800 border-zinc-700"
                  placeholder="Ex: Barbier Senior, Expert Coiffure..."
                />
              </div>
              <div className="space-y-2">
                <Label>Biographie</Label>
                <Textarea
                  value={formData.bio}
                  onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                  className="bg-zinc-800 border-zinc-700"
                  placeholder="Courte description..."
                />
              </div>
              <div className="space-y-2">
                <Label>URL de la photo</Label>
                <Input
                  value={formData.photo_url}
                  onChange={(e) => setFormData({ ...formData, photo_url: e.target.value })}
                  className="bg-zinc-800 border-zinc-700"
                  placeholder="https://..."
                />
              </div>
              <div className="flex items-center justify-between">
                <Label>Barbier actif</Label>
                <Switch
                  checked={formData.is_active}
                  onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
                />
              </div>
              <div className="flex gap-3 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={resetForm}
                  className="flex-1 border-zinc-700"
                >
                  Annuler
                </Button>
                <Button
                  type="submit"
                  disabled={createMutation.isPending || updateMutation.isPending}
                  className="flex-1 bg-amber-500 hover:bg-amber-600 text-black"
                >
                  {(createMutation.isPending || updateMutation.isPending) && (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  )}
                  {editingBarber ? 'Mettre à jour' : 'Ajouter'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-amber-500" />
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {barbers?.map((barber) => (
            <Card key={barber.id} className="bg-zinc-900 border-zinc-800 overflow-hidden">
              <div className="aspect-square overflow-hidden relative">
                {barber.photo_url ? (
                  <img
                    src={barber.photo_url}
                    alt={barber.name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full bg-zinc-800 flex items-center justify-center">
                    <User className="w-20 h-20 text-zinc-600" />
                  </div>
                )}
                {!barber.is_active && (
                  <div className="absolute top-2 left-2 px-2 py-1 bg-zinc-800/90 text-zinc-400 text-xs rounded">
                    Inactif
                  </div>
                )}
              </div>
              <div className="p-4">
                <h3 className="font-semibold text-white text-lg">{barber.name}</h3>
                <p className="text-amber-500 text-sm">{barber.title || 'Barbier'}</p>
                {barber.bio && (
                  <p className="text-gray-400 text-sm mt-2 line-clamp-2">{barber.bio}</p>
                )}
                <div className="flex gap-2 mt-4">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleEdit(barber)}
                    className="flex-1 border-zinc-700 hover:bg-zinc-800"
                  >
                    <Pencil className="w-4 h-4 mr-1" />
                    Modifier
                  </Button>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => handleDelete(barber.id)}
                    className="border-red-900 hover:bg-red-900/20 text-red-500"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </Card>
          ))}

          {barbers?.length === 0 && (
            <div className="col-span-full text-center py-12 text-gray-400">
              Aucun barbier. Ajoutez votre premier barbier!
            </div>
          )}
        </div>
      )}
    </div>
  );
}