import React from 'react';
import { motion } from 'framer-motion';
import { Check, Star } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function BarberSelector({ barbers, selectedBarber, onSelect }) {
  return (
    <div className="space-y-4">
      <h3 className="text-xl font-semibold text-white mb-4">Choisissez votre barbier</h3>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {barbers?.map((barber) => (
          <motion.button
            key={barber.id}
            onClick={() => onSelect(barber)}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className={cn(
              "relative rounded-xl overflow-hidden border-2 transition-all duration-300",
              selectedBarber?.id === barber.id
                ? "border-amber-500"
                : "border-zinc-800 hover:border-zinc-700"
            )}
          >
            {/* Image */}
            <div className="aspect-square overflow-hidden">
              <img
                src={barber.photo_url || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&q=80"}
                alt={barber.name}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
            </div>

            {/* Info */}
            <div className="absolute bottom-0 left-0 right-0 p-3">
              <h4 className={cn(
                "font-semibold transition-colors",
                selectedBarber?.id === barber.id ? "text-amber-500" : "text-white"
              )}>
                {barber.name}
              </h4>
              <p className="text-gray-400 text-xs">{barber.title || "Barbier"}</p>
            </div>

            {/* Selected Indicator */}
            {selectedBarber?.id === barber.id && (
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="absolute top-2 right-2 w-8 h-8 bg-amber-500 rounded-full flex items-center justify-center"
              >
                <Check className="w-5 h-5 text-black" />
              </motion.div>
            )}
          </motion.button>
        ))}
      </div>
    </div>
  );
}